from flask import Flask,render_template

app = Flask(__name__)

@app.route('/')
def home():
    name = [1,2,3,4,5,6,7,8]
    return render_template('home.html',user = name)

@app.route('/index')
def index():
    name_index = 'poovarasan'
    return render_template('index.html',name = name_index)

@app.route('/log')
def log():

    return render_template('log.html')

@app.route('/test4')
def test4():
    return '<h1>Hello welocome to flask 4th</h1>'

if __name__ == '__main__':
    app.run(debug=True)
